# Sudoku Pencil v0.2

Static PWA prototype for iPad/Chrome. Upload this folder to GitHub Pages or another static HTTPS host.
